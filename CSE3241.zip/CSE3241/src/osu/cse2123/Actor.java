package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;

/**
 * A simple class for holding Actor Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Actor {
	// Initializing private variables to edit in class 
    private int actorID;
    private String firstName;
    private String lastName;
    private String bio;
    private String roleType;
    private int collectionID;
    
    public int maxActorID(Connection conn) {
    	int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Actor_ID) FROM ACTORS;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				//System.out.print(value);
				//if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//System.out.print(columnValue);
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
    }
    
	public Actor(String firstName, String lastName, String bio, String roleType, int collectionID, Connection conn) {
		super();
		this.actorID = maxActorID(conn);
		this.firstName = firstName;
		this.lastName = lastName;
		this.bio = bio;
		this.roleType = roleType;
		this.collectionID = collectionID;
	}
	
	@Override
	public String toString() {
        return lastName + ", " + firstName + " " + bio + " " + roleType + " " + actorID + " " + collectionID;
    }

	public int getActorID() {
		return actorID;
	}

	public void setActorID(int actorID) {
		this.actorID = actorID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}
	
	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO ACTORS(Actor_ID, First_Name, Last_Name, Bio, Role_Type, Collection_ID) "
					+ "VALUES (?,?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, actorID);
	   		stmt.setString(2, firstName);
	   		stmt.setString(3, lastName);
	   		stmt.setString(4, bio);
	   		stmt.setString(5, roleType);
	   		stmt.setInt(6, collectionID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public void editEntry(Connection conn, String input) {
		try {
			String sqlStatementTwo = "UPDATE ACTORS " + 
					"SET Actor_ID = ?, First_Name = ?, Last_name = ?, Bio = ?, Role_Type = ?, Collection_ID = ?"
					+ " WHERE Last_Name=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, actorID);
	   		stmt.setString(2, firstName);
	   		stmt.setString(3, lastName);
	   		stmt.setString(4, bio);
	   		stmt.setString(5, roleType);
	   		stmt.setInt(6, collectionID);
	   		stmt.setString(7,  input);
			stmt.executeUpdate(); 
		} catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
}
    
    