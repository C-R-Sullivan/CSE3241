package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;

/**
 * A simple class for holding Audio Book Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Audiobook {
	// Initializing private variables to edit in class 
    private int audiobookId;
    private int numCopies;
    private int numChapters;
    private int numLength;
    public String title;
    private int year;
    private String genre;
    private String type = "Audiobook";
    private int collectionID;
    private int authorID;

    public int maxAudioBookID(Connection conn) {
    	int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Audiobook_ID) FROM AUDIOBOOKS;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				//System.out.print(value);
				//if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//System.out.print(columnValue);
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
    }


	public Audiobook(int collectionId, int numCopies, int numChapters, int numLength, String title, int year,
			String genre, int authorID, Connection conn) {
		super();
		this.audiobookId = maxAudioBookID(conn);
		this.numCopies = numCopies;
		this.numChapters = numChapters;
		this.numLength = numLength;
		this.title = title;
		this.year = year;
		this.genre = genre;
		this.collectionID = collectionId;
		this.authorID = authorID;
	}
	
	public Audiobook() {
	}

	@Override
	public String toString() {
        return title + " " + genre + " " + year + " " + type + " " + audiobookId + " " + collectionID;
    }

	public int getAudiobookId() {
		return audiobookId;
	}

	public void setAudiobookId(int audiobookId) {
		this.audiobookId = audiobookId;
	}

	public int getNumCopies() {
		return numCopies;
	}

	public void setNumCopies(int numCopies) {
		this.numCopies = numCopies;
	}

	public int getNumChapters() {
		return numChapters;
	}

	public void setNumChapters(int numChapters) {
		this.numChapters = numChapters;
	}

	public int getNumLength() {
		return numLength;
	}

	public void setNumLength(int numLength) {
		this.numLength = numLength;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}

	public int getAuthorID() {
		return authorID;
	}

	public void setAuthorID(int authorID) {
		this.authorID = authorID;
	}
	
	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO AUDIOBOOKS (Audiobook_ID, Num_Of_Copies, Chapters, Length, Title, Year, Genre, Type, Collection_ID, Author_ID) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, audiobookId);
	   		stmt.setInt(2, numCopies);
	   		stmt.setInt(3, numChapters);
	   		stmt.setInt(4, numLength);
	   		stmt.setString(5, title);
	   		stmt.setInt(6, year);
	   		stmt.setString(7, genre);
	   		stmt.setString(8, type);
	   		stmt.setInt(9, collectionID);
	   		stmt.setInt(10, authorID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}

	public void editEntry(Connection conn, String input) {
		try {
			String sqlStatementTwo = "UPDATE AUDIOBOOKS " + 
					"SET Audiobook_ID = ?, Num_Of_Copies = ?, Chapters = ?, Length = ?, Title = ?, Year = ?, "
					+ "Genre = ?, Type = ?, Collection_ID = ?, Author_ID = ?"
					+ " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, audiobookId);
	   		stmt.setInt(2, numCopies);
	   		stmt.setInt(3, numChapters);
	   		stmt.setInt(4, numLength);
	   		stmt.setString(5, title);
	   		stmt.setInt(6, year);
	   		stmt.setString(7, genre);
	   		stmt.setString(8, type);
	   		stmt.setInt(9, collectionID);
	   		stmt.setInt(10, authorID);
	   		stmt.setString(11,  input);
			stmt.executeUpdate(); 
		} catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
	
}    

