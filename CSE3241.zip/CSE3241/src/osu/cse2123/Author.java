package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;

/**
 * A simple class for holding Author Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Author {
	// Initializing private variables to edit in class 
    private int authorID;
    private String firstName;
    private String lastName;
    private String bio;
    private String type;
    private int collectionID;
    
    public int maxAuthorID(Connection conn) {
    	int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Author_ID) FROM AUTHORS;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				//System.out.print(value);
				//if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//System.out.print(columnValue);
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
    }
    
	public Author(String firstName, String lastName, String bio, int collectionID, Connection conn) {
		super();
		this.authorID = maxAuthorID(conn);
		this.firstName = firstName;
		this.lastName = lastName;
		this.bio = bio;
		this.type = "Artist";
		this.collectionID = collectionID;
	}
	
	@Override
	public String toString() {
        return lastName + ", " + firstName + " " + bio + " " + type + " " + authorID + " " + collectionID;
    }

	public int getAuthorID() {
		return authorID;
	}

	public void setAuthorID(int artistID) {
		this.authorID = artistID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}
	
	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO AUTHORS(Author_ID, First_Name, Last_Name, Bio, Collection_ID) "
					+ "VALUES (?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, authorID);
	   		stmt.setString(2, firstName);
	   		stmt.setString(3, lastName);
	   		stmt.setString(4, bio);
	   		stmt.setInt(5, collectionID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public void editEntry(Connection conn, String input) {
		try {
			String sqlStatementTwo = "UPDATE AUTHORS " + 
					"SET Author_ID = ?, First_Name = ?, Last_Name = ?, Bio = ?, Collection_ID = ?"
					+ " WHERE Last_Name=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, authorID);
	   		stmt.setString(2, firstName);
	   		stmt.setString(3, lastName);
	   		stmt.setString(4, bio);
	   		stmt.setInt(5, collectionID);
	   		stmt.setString(6,  input);
			stmt.executeUpdate(); 
		} catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
}
    