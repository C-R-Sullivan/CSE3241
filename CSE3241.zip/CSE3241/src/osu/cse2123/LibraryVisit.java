package osu.cse2123;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class LibraryVisit {
	 
	/**
	 *  The database file name.
	 *  
	 *  Make sure the database file is in the root folder of the project if you only provide the name and extension.
	 *  
	 *  Otherwise, you will need to provide an absolute path from your C: drive or a relative path from the folder this class is in.
	 */
	//TODO: Change this
	private static String DATABASE = "Checkpoint5Library.db";
	
    /**
     * Connects to the database if it exists, creates it if it does not, and returns the connection object.
     * 
     * @param databaseFileName the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
    	/**
    	 * The "Connection String" or "Connection URL".
    	 * 
    	 * "jdbc:sqlite:" is the "subprotocol".
    	 * (If this were a SQL Server database it would be "jdbc:sqlserver:".)
    	 */
        String url = "jdbc:sqlite:" + databaseFileName;
        Connection conn = null; // If you create this variable inside the Try block it will be out of scope
        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
            	// Provides some positive assurance the connection and/or creation was successful.
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("The connection to the database was successful.");
            } else {
            	// Provides some feedback in case the connection failed but did not throw an exception.
            	System.out.println("Null Connection");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.out.println("There was a problem connecting to the database.");
        }
        return conn;
    }
    
	/**
	 * Prompts user with display and encourages them to choose one of the options
	 * 
	 * @param keyboard Scanner to read user input
	 * 
	 * @return choice of what user wishes to do
	 */
	public static char userChoice(Scanner keyboard) {
		// define input string for user input and char choice for condensed string
		String input = "";
		char choice = 'R';
		// Prompts user for answer of lower/upper P/A/Q
		while (choice != 'A' && choice != 'B' && choice != 'C' && choice != 'D' && choice != 'E' && choice != 'F' && choice != 'Q') {
			System.out.println("Hello, please select an option (Enter only letter)");
			System.out.println("A. Add new records");
			System.out.println("B. Search Items");
			System.out.println("C. Order Items");
			System.out.println("D. Run a report");
			System.out.println("E. Edit/Delete Items");
			System.out.println("Q. Quit");
			System.out.print("Option: ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
			System.out.println();
		}
		return choice;
	}
	
	public static int getNewCollID(Connection conn) {
		int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Collection_ID) FROM SEARCHABLE;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			//System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
	}
	
	public static void addNewColl(int num, Connection conn) {
		try {
			String sqlStatement = "INSERT INTO SEARCHABLE(Collection_ID) "
					+ "VALUES (?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, num);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public static void addAudioBook(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for an audiobook: ");
		
		System.out.print("Number of Copies: ");
		String copies = keyboard.nextLine();
		int numCopies = Integer.parseInt(copies);
		
		System.out.print("Number of Chapters: ");
		String chaps = keyboard.nextLine();
		int numChapters = Integer.parseInt(chaps);
		
		System.out.print("Length (pages): ");
		String pages = keyboard.nextLine();
		int numLength = Integer.parseInt(pages);
		
		System.out.print("Title: ");
		String title = keyboard.nextLine();
		
		System.out.print("Year Published: ");
		String yearP = keyboard.nextLine();
		int year = Integer.parseInt(yearP);
		
		System.out.print("Genre: ");
		String genre = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		System.out.print("Author ID: ");
		String author = keyboard.nextLine();
		int authorID = Integer.parseInt(author);
		
		Audiobook newBook = new Audiobook(collectionId, numCopies, numChapters, numLength, title, year,genre, authorID, conn);
		newBook.addToDataBase(conn);
		addNewColl(collectionId, conn);
	}
	
	public static void addMovie(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for a movie: ");
		
		System.out.print("Number of Copies: ");
		String copies = keyboard.nextLine();
		int numCopies = Integer.parseInt(copies);
		
		
		System.out.print("Length (minutes): ");
		String pages = keyboard.nextLine();
		int numLength = Integer.parseInt(pages);
		
		System.out.print("Title: ");
		String title = keyboard.nextLine();
		
		System.out.print("Director: ");
		String director = keyboard.nextLine();
		
		System.out.print("Content Rating: ");
		String contentRating = keyboard.nextLine();
		
		System.out.print("Year Published: ");
		String yearP = keyboard.nextLine();
		int year = Integer.parseInt(yearP);
		
		System.out.print("Genre: ");
		String genre = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		Movie newMovie = new Movie(collectionId, numCopies, numLength, title, year,
				genre, director, contentRating, conn);
		newMovie.addToDataBase(conn);
		addNewColl(collectionId, conn);
		
	}
	
	public static void addActor(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for an actor: ");
		
		System.out.print("First Name: ");
		String firstName = keyboard.nextLine();
		
		System.out.print("Last Name: ");
		String lastName = keyboard.nextLine();
		
		System.out.print("Bio: ");
		String bio = keyboard.nextLine();
		
		System.out.print("Role Type: ");
		String roleType = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		Actor newActor = new Actor(firstName, lastName, bio, roleType, collectionId, conn);
		newActor.addToDataBase(conn);
		addNewColl(collectionId, conn);
	}
	
	public static void addTrack(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for a track: ");
		
		System.out.print("Length (minutes): ");
		String pages = keyboard.nextLine();
		int numLength = Integer.parseInt(pages);
		
		System.out.print("Title: ");
		String title = keyboard.nextLine();
		
		System.out.print("Year Published: ");
		String yearP = keyboard.nextLine();
		int year = Integer.parseInt(yearP);
		
		System.out.print("Genre: ");
		String genre = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		System.out.print("Artist ID: ");
		String author = keyboard.nextLine();
		int artistId = Integer.parseInt(author);
		
		Track newTrack = new Track(numLength, title, year, genre, collectionId, artistId, conn);
		newTrack.addToDataBase(conn);
		addNewColl(collectionId, conn);
	}
	
	public static void addAlbum(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for an album: ");
		
		System.out.print("Number of Copies: ");
		String copies = keyboard.nextLine();
		int numCopies = Integer.parseInt(copies);

		System.out.print("Title: ");
		String title = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		System.out.print("Artist ID: ");
		String author = keyboard.nextLine();
		int artistId = Integer.parseInt(author);
		
		
		Album newAlbum = new Album(numCopies, title, collectionId, artistId, conn);
		newAlbum.addToDataBase(conn);
		addNewColl(collectionId, conn);

	}
	
	public static void addArtist(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for an artist: ");
		
		System.out.print("First Name: ");
		String firstName = keyboard.nextLine();
		
		System.out.print("Last Name: ");
		String lastName = keyboard.nextLine();
		
		System.out.print("Bio: ");
		String bio = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		Artist newArtist = new Artist(firstName, lastName, bio, collectionId, conn);
		newArtist.addToDataBase(conn);
		addNewColl(collectionId, conn);
	}
	
	public static void addAuthor(Scanner keyboard, Connection conn) {
		System.out.println("Please submit the new info for an author: ");
		
		System.out.print("First Name: ");
		String firstName = keyboard.nextLine();
		
		System.out.print("Last Name: ");
		String lastName = keyboard.nextLine();
		
		System.out.print("Bio: ");
		String bio = keyboard.nextLine();
		
		int collectionId = getNewCollID(conn);
		
		Author newAuthor = new Author(firstName, lastName, bio, collectionId, conn);
		newAuthor.addToDataBase(conn);
		addNewColl(collectionId, conn);
	}
	
	public static void addItem(Scanner keyboard, Connection conn) {
		char choice = 'R';
		while (choice != 'Q') {
			System.out.println();
			System.out.println("Please select the item you'd like to add (Letter only): ");
			System.out.println("A. Audiobook");
			System.out.println("B. Movie");
			System.out.println("C. Actor");
			System.out.println("D. Track");
			System.out.println("E. Album");
			System.out.println("F. Artist");
			System.out.println("G. Author");
			System.out.println("Q. Return");
			System.out.print("Option: ");
			String input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
			System.out.println();
			
			if (choice == 'A') {
				addAudioBook(keyboard, conn);
			}
			else if (choice == 'B') {
				addMovie(keyboard, conn);
			}
			
			else if (choice == 'C') {
				addActor(keyboard, conn);
			}
			
			else if (choice == 'D') {
				addTrack(keyboard, conn);
			}
			else if (choice == 'E') {
				addAlbum(keyboard, conn);
			}
			else if (choice == 'F') {
				addArtist(keyboard, conn);
			}
			else if (choice == 'G') {
				addAuthor(keyboard, conn);
			}
		}	
	}
	
	public static void editAudioBook(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the title of the Audiobook you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM AUDIOBOOKS" + 
							 " WHERE Title=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Audiobook you'd like to edit: ");
			input = keyboard.nextLine();
			
			System.out.println("Please submit the new info for an audiobook: ");
			
			System.out.print("Number of Copies: ");
			String copies = keyboard.nextLine();
			int numCopies = Integer.parseInt(copies);
			
			System.out.print("Number of Chapters: ");
			String chaps = keyboard.nextLine();
			int numChapters = Integer.parseInt(chaps);
			
			System.out.print("Length (pages): ");
			String pages = keyboard.nextLine();
			int numLength = Integer.parseInt(pages);
			
			System.out.print("Title: ");
			String title = keyboard.nextLine();
			
			System.out.print("Year Published: ");
			String yearP = keyboard.nextLine();
			int year = Integer.parseInt(yearP);
			
			System.out.print("Genre: ");
			String genre = keyboard.nextLine();
			
			int collectionId = getNewCollID(conn);
			
			System.out.print("Author ID: ");
			String author = keyboard.nextLine();
			int authorID = Integer.parseInt(author);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Audiobook newBook = new Audiobook(collectionId, numCopies, numChapters, numLength, title, year,genre, authorID, conn);
				newBook.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editMovie(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the title of the movie you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM MOVIES" + 
							 " WHERE Title=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Movie you'd like to edit: ");
			input = keyboard.nextLine();
		
			System.out.println("Please submit the new info for a movie: ");
			
			System.out.print("Number of Copies: ");
			String copies = keyboard.nextLine();
			int numCopies = Integer.parseInt(copies);
	
			
			System.out.print("Length (minutes): ");
			String pages = keyboard.nextLine();
			int numLength = Integer.parseInt(pages);
	
			
			System.out.print("Title: ");
			String title = keyboard.nextLine();
	
			
			System.out.print("Director: ");
			String director = keyboard.nextLine();
	
			
			System.out.print("Content Rating: ");
			String contentRating = keyboard.nextLine();
	
			
			System.out.print("Year Published: ");
			String yearP = keyboard.nextLine();
			int year = Integer.parseInt(yearP);
	
			
			System.out.print("Genre: ");
			String genre = keyboard.nextLine();
	
			int collectionId = getNewCollID(conn);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {		
				Movie newMovie = new Movie(collectionId, numCopies, numLength, title, year, genre, director, contentRating, conn);
				newMovie.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editActor(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the last name of the actor you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM ACTORS" + 
							 " WHERE Last_Name=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Actor you'd like to edit: ");
			input = keyboard.nextLine();
		
			System.out.println("Please submit the new info for an actor: ");
			
			System.out.print("First Name: ");
			String firstName = keyboard.nextLine();
	
			
			System.out.print("Last Name: ");
			String lastName = keyboard.nextLine();
	
			
			System.out.print("Bio: ");
			String bio = keyboard.nextLine();
	
			
			System.out.print("Role Type: ");
			String roleType = keyboard.nextLine();
			
			int collectionId = getNewCollID(conn);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Actor newActor = new Actor(firstName, lastName, bio, roleType, collectionId, conn);
				newActor.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editAlbum(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the title of the album you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM ALBUMS" + 
							 " WHERE Title=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Album you'd like to edit: ");
			input = keyboard.nextLine();
			
			System.out.println("Please submit the new info for an album: ");
			
			System.out.print("Number of Copies: ");
			String copies = keyboard.nextLine();
			int numCopies = Integer.parseInt(copies);
	
	
			System.out.print("Title: ");
			String title = keyboard.nextLine();
	
			int collectionId = getNewCollID(conn);
			
			System.out.print("Artist ID: ");
			String author = keyboard.nextLine();
			int artistId = Integer.parseInt(author);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Album newAlbum = new Album(numCopies, title, collectionId, artistId, conn);
				newAlbum.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editTrack(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the title of the title you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM TRACKS" + 
							 " WHERE Title=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Track you'd like to edit: ");
			input = keyboard.nextLine();
		
			System.out.println("Please submit the new info for a track: ");
			
			System.out.print("Length (minutes): ");
			String pages = keyboard.nextLine();
			int numLength = Integer.parseInt(pages);
	
			
			System.out.print("Title: ");
			String title = keyboard.nextLine();
	
			
			System.out.print("Year Published: ");
			String yearP = keyboard.nextLine();
			int year = Integer.parseInt(yearP);
	
			
			System.out.print("Genre: ");
			String genre = keyboard.nextLine();
			int collectionId = getNewCollID(conn);
			
			System.out.print("Artist ID: ");
			String author = keyboard.nextLine();
			int artistId = Integer.parseInt(author);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Track newTrack = new Track(numLength, title, year, genre, collectionId, artistId, conn);
				newTrack.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editArtist(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the last name of the artist you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM ARTIST" + 
							 " WHERE Last_Name=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Artist you'd like to edit: ");
			input = keyboard.nextLine();
		
			System.out.println("Please submit the new info for an artist: ");
			
			System.out.print("First Name: ");
			String firstName = keyboard.nextLine();
	
			
			System.out.print("Last Name: ");
			String lastName = keyboard.nextLine();
	
			
			System.out.print("Bio: ");
			String bio = keyboard.nextLine();
	
			int collectionId = getNewCollID(conn);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Artist newArtist = new Artist(firstName, lastName, bio, collectionId, conn);
				newArtist.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void editAuthor(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'E' && choice != 'D') {
			System.out.print("Would you like to edit (E) or delete (D) a record? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'D') {
			System.out.println("Please enter the last name of the author you'd like to delete: ");
			input = keyboard.nextLine();
			System.out.print("Do you want to save your deletion of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				try {
					String sqlStatementTwo = "DELETE FROM AUTHOR" + 
							 " WHERE Last_Name=?;";
					PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
					stmt.setString(1, input);
					stmt.executeUpdate(); 
				} catch (SQLException e) {
		            System.out.println(e.getMessage());
		        }
			}
		}
		else {
			System.out.println("Please enter the name of the Author you'd like to edit: ");
			input = keyboard.nextLine();
		
			System.out.println("Please submit the new info for an author: ");
			
			System.out.print("First Name: ");
			String firstName = keyboard.nextLine();
	
			
			System.out.print("Last Name: ");
			String lastName = keyboard.nextLine();
	
			
			System.out.print("Bio: ");
			String bio = keyboard.nextLine();
	
			int collectionId = getNewCollID(conn);
			
			System.out.print("Do you want to save your edit of " + input + "?(Y/N): ");
			String ans = keyboard.nextLine().toUpperCase();
			choice = ans.charAt(0);
			if (choice == 'Y') {
				Author newAuthor = new Author(firstName, lastName, bio, collectionId, conn);
				newAuthor.editEntry(conn, input);
				addNewColl(collectionId, conn);
			}
		}
	}
	
	public static void runEdit(Scanner keyboard, Connection conn) {
		char choice = 'R';
		while (choice != 'Q') {
			System.out.println();
			System.out.println("Please select the item you'd like to edit or delete (Letter only): ");
			System.out.println("A. Audiobook");
			System.out.println("B. Movie");
			System.out.println("C. Actor");
			System.out.println("D. Track");
			System.out.println("E. Album");
			System.out.println("F. Artist");
			System.out.println("F. Author");
			System.out.println("Q. Return");
			System.out.print("Option: ");
			String input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
			System.out.println();
			
			if (choice == 'A') {
				editAudioBook(keyboard, conn);
			}
			else if (choice == 'B') {
				editMovie(keyboard, conn);
			}
			
			else if (choice == 'C') {
				editActor(keyboard, conn);
			}
			
			else if (choice == 'D') {
				editTrack(keyboard, conn);
			}
			else if (choice == 'E') {
				editAlbum(keyboard, conn);
			}
			else if (choice == 'F') {
				editArtist(keyboard, conn);
			}
			else if (choice == 'G') {
				editAuthor(keyboard, conn);
			}
		}	
	}
	
	public static void searchAudioBook(Scanner keyboard, Connection conn) {
		System.out.print("Enter the title of an audiobook to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM AUDIOBOOKS" + 
					 " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		
		System.out.println();

	}

	public static void searchMovie(Scanner keyboard, Connection conn) {
		System.out.print("Enter the title of a movie to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM MOVIES" + 
					 " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}

	public static void searchActor(Scanner keyboard, Connection conn) {
		System.out.print("Enter the last name of an actor to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM ACTORS" + 
					 " WHERE Last_Name=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}

	public static void searchTrack(Scanner keyboard, Connection conn) {
		System.out.print("Enter the title of a track to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM TRACKS" + 
					 " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}

	public static void searchAlbum(Scanner keyboard, Connection conn) {
		System.out.print("Enter the title of an album to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM ALBUMS" + 
					 " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}

	public static void searchArtist(Scanner keyboard, Connection conn) {
		System.out.print("Enter the last name of an artist to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM ARTISTS" + 
					 " WHERE Last_Name=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}
	
	public static void searchAuthor(Scanner keyboard, Connection conn) {
		System.out.print("Enter the last name of an artist to search for: ");
		String input = keyboard.nextLine();
		try {
			String sqlStatementTwo = "SELECT * FROM AUTHORS" + 
					 " WHERE Last_Name=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setString(1, input);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				System.out.print(value);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		System.out.println();
	}
	
	public static void searchItems(Scanner keyboard, Connection conn) {
		char choice = 'R';
		while (choice != 'Q') {
			System.out.println("Please select the item you'd like to search for (Letter only): ");
			System.out.println("A. Audiobook");
			System.out.println("B. Movie");
			System.out.println("C. Actor");
			System.out.println("D. Track");
			System.out.println("E. Album");
			System.out.println("F. Artist");
			System.out.println("G. Author");
			System.out.println("Q. Return");
			System.out.print("Option: ");
			String input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
			System.out.println();
			
			if (choice == 'A') {
				searchAudioBook(keyboard, conn);
			}
			else if (choice == 'B') {
				searchMovie(keyboard, conn);
			}
			
			else if (choice == 'C') {
				searchActor(keyboard, conn);
			}
			
			else if (choice == 'D') {
				searchTrack(keyboard, conn);
			}
			else if (choice == 'E') {
				searchAlbum(keyboard, conn);
			}
			else if (choice == 'F') {
				searchArtist(keyboard, conn);
			}
			else if (choice == 'G') {
				searchAuthor(keyboard, conn);
			}
		}
	}
	
	public static void orderItems(Scanner keyboard, Connection conn) {
		char choice = 'R';
		String input = "";
		while (choice != 'S' && choice != 'A') {
			System.out.print("Would you like to (S)tart an order or (A)ctivate a new one? ");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
		}
		if (choice == 'S') {
			System.out.println("Please submit the new info for an order: ");
			
			System.out.print("Media Type: ");
			String mediaType = keyboard.nextLine();
			
			System.out.print("Arrival Date: ");
			String arrivalDate = keyboard.nextLine();
			
			System.out.print("Number of Copies: ");
			String copies = keyboard.nextLine();
			int numCopies = Integer.parseInt(copies);
			
			System.out.print("Cost of Order: ");
			String cost = keyboard.nextLine();
			Double price = Double.parseDouble(cost);

			int collectionId = getNewCollID(conn);
			
			Ordered order = new Ordered(mediaType, arrivalDate, numCopies, price, collectionId);
			order.addToDataBase(conn);
			addNewColl(collectionId, conn);
			System.out.println("Order placed!");
		}
		else {
			System.out.println("Please enter a Collection ID to activate your item: ");
			String id = keyboard.nextLine();
			int collID = Integer.parseInt(id);
			try {
				String sqlStatementTwo = "DELETE FROM ORDERED" + 
						 " WHERE Collection_ID=?;";
				PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
				stmt.setInt(1, collID);
				stmt.executeUpdate(); 
			} catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
			choice = 'W';
			while (choice != 'A' && choice != 'B' && choice != 'C') {
				System.out.println("Please select the item type you are activating (Letter only): ");
				System.out.println("A. Audiobook");
				System.out.println("B. Movie");
				System.out.println("C. Album");
				System.out.print("Option: ");
				String use = keyboard.nextLine().toUpperCase();
				choice = use.charAt(0);
				System.out.println();
			}
			try {
				String sqlStatementTwo = "DELETE FROM SEARCHABLE" + 
						 " WHERE Collection_ID=?;";
				PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
				stmt.setInt(1, collID);
				stmt.executeUpdate(); 
			} catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
			if (choice == 'A') {
				addAudioBook(keyboard, conn);
			}
			else if (choice == 'B') {
				addMovie(keyboard, conn);
			}
			else if (choice == 'C') {
				addAlbum(keyboard, conn);
			}
		}	
	}
	
	public static void totalCheckouts(Connection conn, Scanner keyboard) {
		System.out.print("Enter the Card ID of a patron: ");
		String input = keyboard.nextLine();
		int value = Integer.parseInt(input);
		try {
			String sqlStatementTwo = "SELECT U.Card_ID, First_Name, Last_Name, COUNT(C.Card_ID) AS count "
					+ "FROM USERS AS U, CHECKOUT_INSTANCE as C "
					+ "WHERE U.Card_ID = C.Card_ID "
					+ "AND U.Card_ID = ? "
					+ "GROUP BY U.Card_ID;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, value);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		
		System.out.println();
	}

	public static void popularActor(Connection conn, Scanner keyboard) {
		try {
			String sqlStatementTwo = "SELECT First_Name, Last_Name, COUNT(A.Actor_ID) AS Count "
					+ "FROM ACTORS AS S, MOVIES AS M, CHECKOUT_INSTANCE AS C, ACTOR_ACTS_IN AS A "
					+ "WHERE M.Collection_ID = C.Collection_ID "
					+ "AND S.Actor_ID = A.Actor_ID "
					+ "AND M.Movie_ID = A.Movie_ID "
					+ "ORDER BY Count DESC "
					+ "LIMIT 1;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
		}
	
	public static void popularArtist(Connection conn, Scanner keyboard) {
		try {
			String sqlStatementTwo = "SELECT First_Name, Last_Name,  COUNT(C.Collection_ID) AS Instances, SUM(T.Length) AS Total, COUNT(C.Collection_ID) * SUM(T.Length) AS TIME_LISTENED "
					+ "FROM ARTISTS AS S, ALBUMS AS A, TRACKS AS T, CHECKOUT_INSTANCE AS C "
					+ "WHERE A.Collection_ID = C.Collection_ID "
					+ "AND A.Artist_ID = T.Artist_ID "
					+ "GROUP BY Last_Name "
					+ "ORDER BY TIME_LISTENED DESC "
					+ "LIMIT 1;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	public static void popularAuthor(Connection conn, Scanner keyboard) {
		try {
			String sqlStatementTwo = "SELECT First_Name, Last_Name,  COUNT(C.Collection_ID) AS Instances, SUM(A.Length) AS Total, COUNT(C.Collection_ID) * SUM(A.Length) AS TIME_LISTENED "
					+ "FROM AUTHORS AS S, AUDIOBOOKS AS A, CHECKOUT_INSTANCE AS C "
					+ "WHERE A.Collection_ID = C.Collection_ID "
					+ "AND S.Author_ID = A.Author_ID "
					+ "GROUP BY Last_Name "
					+ "ORDER BY TIME_LISTENED DESC "
					+ "LIMIT 1;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public static void mostMovies(Connection conn, Scanner keyboard) {
		try {
			String sqlStatementTwo = "SELECT First_Name, Last_Name, Email, COUNT(C.Collection_ID) AS Total_Movies "
					+ "FROM MOVIES AS M, USERS AS U, CHECKOUT_INSTANCE AS C "
					+ "WHERE M.Collection_ID = C.Collection_ID "
					+ "AND U.Card_ID = C.Card_ID "
					+ "GROUP BY Email "
					+ "ORDER BY Total_Movies DESC "
					+ "LIMIT 1;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	public static void tracksByAuthor(Connection conn, Scanner keyboard) {
		System.out.print("Enter the Artist_ID of an Artist: ");
		String input = keyboard.nextLine();
		int value = Integer.parseInt(input);
		System.out.print("Enter the year to search before: ");
		String inputTwo = keyboard.nextLine();
		int valueTwo = Integer.parseInt(inputTwo);
		try {
			String sqlStatementTwo = "SELECT Title, Year "
					+ "FROM ARTISTS AS A, TRACKS AS T "
					+ "WHERE T.Artist_ID = A.Artist_ID "
					+ "AND A.Artist_ID = ? "
					+ "AND Year < ? ;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, value);
			stmt.setInt(2, valueTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String str = rsmd.getColumnName(i);
				System.out.print(str);
				if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
            		System.out.print(columnValue);
            		if (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public static void runReport(Scanner keyboard, Connection conn) {
		String input = "";
		char choice = 'P';
		while (choice != 'Q') {
			System.out.println("Please select a query to run: ");
			System.out.println("A. Total checkouts by user");
			System.out.println("B. Most popular Actor");
			System.out.println("C. Most popular Artist");
			System.out.println("D. Most popular Author");
			System.out.println("E. Patron with most vidoes");
			System.out.println("F. Tracks by Artist");
			System.out.println("Q. Return");
			input = keyboard.nextLine().toUpperCase();
			choice = input.charAt(0);
			
			if (choice == 'A') {
				totalCheckouts(conn, keyboard);
			}
			
			else if (choice == 'B') {
				popularActor(conn, keyboard);
			}
			
			else if (choice == 'C') {
				popularArtist(conn, keyboard);
			}
			else if (choice == 'D') {
				popularAuthor(conn, keyboard);
			}
			
			else if (choice == 'E') {
				mostMovies(conn, keyboard);
			}
			else if (choice == 'F') {
				tracksByAuthor(conn, keyboard);
			}
			
		}
	}
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("This is a new run");
		Connection conn = initializeDB(DATABASE);
		char choice = 'R';
		while (choice != 'Q') {
			choice = userChoice(keyboard);
			if (choice == 'A') {
				addItem(keyboard, conn);
			}
			
			else if (choice == 'B') {
				searchItems(keyboard, conn);
			}
			
			else if (choice == 'C') {
				orderItems(keyboard, conn);
			}
			else if (choice == 'D') {
				runReport(keyboard, conn);
			}
			
			else if (choice == 'E') {
				runEdit(keyboard, conn);
			}
		}	
	
		System.out.println("Goodbye!");
		keyboard.close();
	}
}
