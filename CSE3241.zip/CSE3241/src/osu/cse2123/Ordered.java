package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;
/**
 * A simple class for holding Actor Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Ordered {
	// Initializing private variables to edit in class 
    private String mediaType;
    private String arrivalDate;
    private int numCopies;
    private double price;
    private int collectionID;
    
	public Ordered(String mediaType, String arrivalDate, int numCopies, double price, int collectionID) {
		super();
		this.mediaType = mediaType;
		this.arrivalDate = arrivalDate;
		this.numCopies = numCopies;
		this.price = price;
		this.collectionID = collectionID;
	}

	public String getMediaType() {
		return mediaType;
	}

	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public int getNumCopies() {
		return numCopies;
	}

	public void setNumCopies(int numCopies) {
		this.numCopies = numCopies;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}

	@Override
	public String toString() {
		return "Ordered [mediaType=" + mediaType + ", arrivalDate=" + arrivalDate + ", numCopies=" + numCopies
				+ ", price=" + price + ", collectionID=" + collectionID + "]";
	}
	
	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO ORDERED(Media_Type, EDOA, Num_Of_Copies, Price, Collection_ID) "
					+ "VALUES (?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setString(1, mediaType);
	   		stmt.setString(2, arrivalDate);
	   		stmt.setInt(3, numCopies);
	   		stmt.setDouble(4, price);
	   		stmt.setInt(5, collectionID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
}
