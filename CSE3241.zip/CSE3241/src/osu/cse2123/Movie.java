package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;
/**
 * A simple class for holding Movie Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Movie {
	// Initializing private variables to edit in class 
    private int movieId;
    private int numCopies;
    private int numLength;
    private String title;
    private int year;
    private String genre;
    private String contentRating;
    private String type = "Movie";
    private int collectionID;
    private String director = "";

    public int maxMovieID(Connection conn) {
    	int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Movie_ID) FROM MOVIES;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				//System.out.print(value);
				//if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//System.out.print(columnValue);
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
    }

	public Movie(int collectionId, int numCopies, int numLength, String title, int year,
			String genre, String director, String contentRating, Connection conn) {
		super();
		this.movieId = maxMovieID(conn);
		this.numCopies = numCopies;
		this.numLength = numLength;
		this.title = title;
		this.year = year;
		this.genre = genre;
		this.director = director;
		this.collectionID = collectionId;
		this.contentRating = contentRating;
	}
	
	@Override
	public String toString() {
        return title + " " + genre + " " + director +" "+ contentRating + " " + type + " " + year + " " + movieId;
    }

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public int getNumCopies() {
		return numCopies;
	}

	public void setNumCopies(int numCopies) {
		this.numCopies = numCopies;
	}

	public int getNumLength() {
		return numLength;
	}

	public void setNumLength(int numLength) {
		this.numLength = numLength;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getContentRating() {
		return contentRating;
	}

	public void setContentRating(String contentRating) {
		this.contentRating = contentRating;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO MOVIES (Movie_ID, Num_Of_Copies, Year, Length, Content_Rating, Genre, Director, Title, Type, Collection_ID) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, movieId);
	   		stmt.setInt(2, numCopies);
	   		stmt.setInt(3, year);
	   		stmt.setInt(4, numLength);
	   		stmt.setString(5, contentRating);
	   		stmt.setString(6, genre);
	   		stmt.setString(7, director);
	   		stmt.setString(8, title);
	   		stmt.setString(9, type);
	   		stmt.setInt(10, collectionID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}
	
	public void editEntry(Connection conn, String input) {
		try {
			String sqlStatementTwo = "UPDATE MOVIES " + 
					"SET Movie_ID = ?, Num_Of_Copies = ?, Year = ?, Length = ?, Content_Rating = ?, "
					+ "Genre = ?, Director = ?, Title = ?, Type = ?, Collection_ID = ?"
					+ " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, movieId);
	   		stmt.setInt(2, numCopies);
	   		stmt.setInt(3, year);
	   		stmt.setInt(4, numLength);
	   		stmt.setString(5, contentRating);
	   		stmt.setString(6, genre);
	   		stmt.setString(7, director);
	   		stmt.setString(8, title);
	   		stmt.setString(9, type);
	   		stmt.setInt(10, collectionID);
	   		stmt.setString(11,  input);
			stmt.executeUpdate(); 
		} catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
}    