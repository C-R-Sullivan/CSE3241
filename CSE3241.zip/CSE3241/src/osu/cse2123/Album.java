package osu.cse2123;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Connection;

/**
 * A simple class for holding Album Information.
 *
 * @author Corey Sullivan
 * @version 02/28/2022
*/

public class Album {
	// Initializing private variables to edit in class 
    private int albumId;
    private int numCopies;
    private String title;
    private String type;
    private int collectionID;
    private int artistID;
    
    public int maxAlbumID(Connection conn) {
    	int result = 1;
    	try {
			String sqlStatementTwo = "SELECT MAX(Album_ID) FROM ALBUMS;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				String value = rsmd.getColumnName(i);
				//System.out.print(value);
				//if (i < columnCount) System.out.print(",  ");
			}
			System.out.print("\n");
        	while (rs.next()) {
        		for (int i = 1; i <= columnCount; i++) {
        			String columnValue = rs.getString(i);
        			if (columnValue != null) {
        				result = Integer.parseInt(columnValue);
            			//System.out.print(columnValue);
        			}
            		//System.out.print(columnValue);
            		//f (i < columnCount) System.out.print(",  ");
        		}
    			System.out.print("\n");
        	}
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    	return result + 1;
    }
    
	public Album(int numCopies, String title, int collectionID, int artistID, Connection conn) {
		super();
		this.albumId = maxAlbumID(conn);
		this.numCopies = numCopies;
		this.title = title;
		this.type = "Album";
		this.collectionID = collectionID;
		this.artistID = artistID;
	}
	
	@Override
	public String toString() {
        return title + " " + numCopies + " " + type + " " + albumId + " " + collectionID + " " + artistID;
    }

	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public int getNumCopies() {
		return numCopies;
	}

	public void setNumCopies(int numCopies) {
		this.numCopies = numCopies;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getCollectionID() {
		return collectionID;
	}

	public void setCollectionID(int collectionID) {
		this.collectionID = collectionID;
	}

	public int getArtistID() {
		return artistID;
	}

	public void setArtistID(int artistID) {
		this.artistID = artistID;
	}
	
	public void addToDataBase(Connection conn) {
		try {
			String sqlStatement = "INSERT INTO ALBUMS(Album_ID, Title, Num_Of_Copies, Type, Artist_ID, Collection_ID) "
					+ "VALUES (?,?,?,?,?,?);";
	   		PreparedStatement stmt = conn.prepareStatement(sqlStatement);
	   		stmt.setInt(1, albumId);
	   		stmt.setString(2, title);
	   		stmt.setInt(3, numCopies);
	   		stmt.setString(4, type);
	   		stmt.setInt(5, artistID);
	   		stmt.setInt(6, collectionID);
	   		stmt.executeUpdate(); 	
		} catch (SQLException e) {
            System.out.println(e.getMessage());
        }
	}	
	
	public void editEntry(Connection conn, String input) {
		try {
			String sqlStatementTwo = "UPDATE ALBUMS " + 
					"SET Album_ID = ?, Title = ?, Num_Of_Copies = ?, Type = ?, Artist_ID = ?, Collection_ID = ?"
					+ " WHERE Title=?;";
			PreparedStatement stmt = conn.prepareStatement(sqlStatementTwo);
			stmt.setInt(1, albumId);
			stmt.setString(2, title);
	   		stmt.setInt(3, numCopies);
	   		stmt.setString(4, type);
	   		stmt.setInt(5, artistID);
	   		stmt.setInt(6, collectionID);
	   		stmt.setString(7,  input);
			stmt.executeUpdate(); 
		} catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	}
}
    